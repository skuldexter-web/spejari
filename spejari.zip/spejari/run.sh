#!/usr/bin/env bash
# Launch Spejari with the right interpreter and root privileges.
cd "$(dirname "$(readlink -f "$0")")" || exit 1
PY=".venv/bin/python"
[ -x "$PY" ] || PY="$(command -v python3)"
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$PY" main.py "$@"
fi
exec "$PY" main.py "$@"
